#include <iostream>
#include <stdexcept>  // For standard exceptions
#include <exception>  // Base exception class
#include <string>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    CustomException(const std::string& msg) : message(msg) {}

    const char* what() const noexcept override {
        return message.c_str();
    }

private:
    std::string message;
};

bool do_even_more_custom_application_logic()
{
    // Throwing a standard exception
    throw std::runtime_error("Standard runtime error occurred in even more custom logic.");

    std::cout << "Running Even More Custom Application Logic." << std::endl;
    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    } catch (const std::exception& e) {
        // Catching and displaying standard exception
        std::cout << "Standard exception caught in do_custom_application_logic: " << e.what() << std::endl;
    }

    //Throw a custom exception derived from std::exception
    throw CustomException("Custom exception thrown from do_custom_application_logic.");

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // Throwing a standard C++ exception for divide-by-zero
    if (den == 0.0f) {
        throw std::invalid_argument("Division by zero error.");
    }

    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    } catch (const std::invalid_argument& e) {
        // Catch ONLY the divide-by-zero exception
        std::cout << "Caught division exception: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests" << std::endl;

    //  Top-level catch-all exception handler
    try {
        do_division();
        do_custom_application_logic();
    } catch (const CustomException& ce) {
        std::cout << "Custom exception caught in main: " << ce.what() << std::endl;
    } catch (const std::exception& se) {
        std::cout << "Standard exception caught in main: " << se.what() << std::endl;
    } catch (...) {
        std::cout << "Unknown exception caught in main!" << std::endl;
    }

    return 0;
}
