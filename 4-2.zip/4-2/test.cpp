#include "pch.h"
//#include "gtest/gtest.h"

#include <vector>
#include <memory>
#include <cassert>
#include <stdexcept>
#include <ctime>

class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    void SetUp() override
    {
        srand(time(nullptr));
    }

    void TearDown() override {}
};

class CollectionTest : public ::testing::Test
{
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        collection->clear();
        collection.reset(nullptr);
    }

    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, AlwaysFail)
{
    FAIL(); 
}

TEST_F(CollectionTest, CanAddToEmptyVector)
{
    ASSERT_TRUE(collection->empty());
    add_entries(1);
    ASSERT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 1);
}

TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);
    EXPECT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, MaxSizeIsGreaterOrEqualToSize)
{
    std::vector<int> sizes = { 0, 1, 5, 10 };
    for (int count : sizes)
    {
        collection->clear();  // Reset the collection manually
        if (count > 0) add_entries(count);
        EXPECT_GE(collection->max_size(), collection->size());
    }
}

TEST_F(CollectionTest, CapacityIsGreaterOrEqualToSize)
{
    std::vector<int> sizes = { 0, 1, 5, 10 };
    for (int count : sizes)
    {
        collection->clear();
        if (count > 0) add_entries(count);
        EXPECT_GE(collection->capacity(), collection->size());
    }
}

TEST_F(CollectionTest, ResizingIncreasesCollection)
{
    collection->resize(5);
    EXPECT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, ResizingDecreasesCollection)
{
    collection->resize(10);
    collection->resize(3);
    EXPECT_EQ(collection->size(), 3);
}

TEST_F(CollectionTest, ResizingToZeroClearsCollection)
{
    collection->resize(5);
    collection->resize(0);
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, ClearErasesCollection)
{
    add_entries(5);
    collection->clear();
    EXPECT_TRUE(collection->empty());
}

TEST_F(CollectionTest, EraseAllElementsUsingRange)
{
    add_entries(5);
    collection->erase(collection->begin(), collection->end());
    EXPECT_TRUE(collection->empty());
}

TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    add_entries(5);
    size_t old_capacity = collection->capacity();
    size_t old_size = collection->size();
    collection->reserve(old_capacity + 10);
    EXPECT_EQ(collection->size(), old_size);
    EXPECT_GE(collection->capacity(), old_capacity + 10);
}

TEST_F(CollectionTest, ThrowsOutOfRangeException)
{
    add_entries(3);
    EXPECT_THROW(collection->at(5), std::out_of_range);
}

// Custom test - Positive: Check values added are within range
TEST_F(CollectionTest, ValuesAreInExpectedRange)
{
    add_entries(10);
    for (int val : *collection)
    {
        EXPECT_GE(val, 0);
        EXPECT_LT(val, 100);
    }
}

// Custom test - Negative: Accessing empty collection index throws
TEST_F(CollectionTest, AccessingEmptyCollectionThrows)
{
    EXPECT_THROW(collection->at(0), std::out_of_range);
}
